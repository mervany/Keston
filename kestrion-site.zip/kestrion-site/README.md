# Kestrion — tanıtım sitesi

Bu depo **yalnızca herkese açık yüzü** barındırır:

```
index.html     Kurumsal tanıtım sitesi
panel/         Demo operatör paneli (örnek veriyle çalışır)
```

GitHub Pages ile yayınlanır. Depo public olmak zorundadır, çünkü Pages
ücretsiz planda yalnızca public depolarda çalışır.

## Burada OLMAYAN şeyler

Ürünün kendisi bu depoda değil. Backend, veritabanı şeması, abonelik
mantığı, ödeme imzaları ve şifreleme ayrı bir **private** depoda durur.
Bu ayrım bilinçlidir: tanıtım sitesi herkese açıktır, ürün değildir.

Bu depoya asla eklenmez: `.env`, API anahtarı, veritabanı bağlantısı,
gerçek müşteri görüntüsü veya gerçek olay verisi.

## Demo paneli

Örnek veriyle çalışır, hiçbir sunucuya bağlanmaz. Giriş ekranı herhangi
bir e-posta ve 6+ haneli parolayı kabul eder — doğrulama yoktur.

Demo hesabı: `demo@kestrion.com`

## Yayınlama

1. Depoyu public olarak oluştur, bu klasörü push et
2. Settings → Pages → Source: `main` / `root`
3. Birkaç dakika sonra `https://<kullanıcı>.github.io/kestrion-site/`
